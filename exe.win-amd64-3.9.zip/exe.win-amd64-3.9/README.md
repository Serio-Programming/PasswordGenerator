>WHAT IS IT?
This is a password generating program created by Tyler Serio circa May 2021. It can generate billions of unique passwords!

>WHAT DOES IT DO?
This program generates a password by combining randomly selected numbers, words, and symbols to create a silly and easy to remember phrase.

>HOW DOES IT DO IT?
The program makes use of several functions that access text files containing words. Then it takes the words that were randomly selected from these files and combines them in a semi-random way, along with a number and special character.

>HOW DO I USE IT?
You simply begin the program and it will automatically generate a password. Then you can choose to generate more, or close the program. You can also add your own words to the included text files, to increase the number of possible passwords.

>WHAT FILES ARE INCLUDED?
This program comes with several different files. These are adjectives.txt, nouns.txt, verbs.txt, verbs2.txt, the README.txt file, a lib folder that contains relevant Python modules, two .dll files, and the PasswordGenerator.py file. These files are necessary to run the program and it will not function without them.

>DANCE PARTY:
~~~~~~~~~~~~~~~~~~~~~~
 ooo..   oooo   ..ooo 
<('' <)(> '' <)(> '')>
___00_____00_____00___
